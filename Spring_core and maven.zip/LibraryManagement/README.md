# Library Management Spring Project

This project demonstrates:
- Spring Core
- Dependency Injection
- Setter Injection
- XML Configuration
- IoC Container

## Expected Output

Book Service is working
Book Repository is working
